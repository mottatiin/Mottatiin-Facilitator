﻿using System;
using System.Diagnostics;
using System.IO;
using System.Threading;


class Program
{
    static void Main()
    {
        bool determine = false;
        
        string url = "https://discord.gg/Y3n3wRHgj7"; // Substitua pela URL que deseja abrir

        Process.Start("cmd", $"/c start {url}");
        while (true)
        {
            // Defina um array de cores disponíveis
            ConsoleColor[] coresDisponiveis = { ConsoleColor.Magenta, ConsoleColor.Red, ConsoleColor.Red };
            Console.Title = "Mottatiin Facilitator - FiveM";

            // Escolha uma cor aleatória do array
            ConsoleColor corAleatoria = coresDisponiveis[new Random().Next(coresDisponiveis.Length)];

            Console.ForegroundColor = corAleatoria;

            string texto =
                " __  __         _    _           _    _  _          ______               _  _  _  _           _                \r\n" +
                "|  \\/  |       | |  | |         | |  (_)(_)        |  ____|             (_)| |(_)| |         | |               \r\n" +
                "| \\  / |  ___  | |_ | |_   __ _ | |_  _  _  _ __   | |__     __ _   ___  _ | | _ | |_   __ _ | |_   ___   _ __ \r\n" +
                "| |\\/| | / _ \\ | __|| __| / _` || __|| || || '_ \\  |  __|   / _` | / __|| || || || __| / _` || __| / _ \\ | '__|\r\n" +
                "| |  | || (_) || |_ | |_ | (_| || |_ | || || | | | | |     | (_| || (__ | || || || |_ | (_| || |_ | (_) || |   \r\n" +
                "|_|  |_| \\___/  \\__| \\__| \\__,_| \\__||_||_||_| |_| |_|      \\__,_| \\___||_||_||_| \\__| \\__,_| \\__| \\___/ |_|   \r\n";

            string texto2 =
                " _        ____             _____   _____  _   _   _____ \r\n" +
                "| |      / __ \\     /\\    |  __ \\ |_   _|| \\ | | / ____|\r\n" +
                "| |     | |  | |   /  \\   | |  | |  | |  |  \\| || |  __ \r\n" +
                "| |     | |  | |  / /\\ \\  | |  | |  | |  | . ` || | |_ |\r\n" +
                "| |____ | |__| | / ____ \\ | |__| | _| |_ | |\\  || |__| | _  _  _ \r\n" +
                "|______| \\____/ /_/    \\_\\|_____/ |_____||_| \\_| \\_____|(_)(_)(_)\r\n";

            // Divida o texto em linhas e escreva cada linha lentamente
            string[] linhas = texto2.Split('\n');

            if (determine == false)
            {

                foreach (string linha in linhas)
                {
                    EscreverLentamente(linha);
                    Console.WriteLine(); // Avança para a próxima linha
                }
                Thread.Sleep(1500);
                Console.Clear();
                Console.WriteLine(texto);
                determine = true;
            }
            else
            {
                Console.WriteLine(texto);
            }

            Console.WriteLine("\n\nSelecione uma opção:\n");
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write("[");
            Console.ForegroundColor = corAleatoria;
            Console.Write("1");
            Console.ResetColor();
            Console.Write("] Opções\n");
            /////////////
            Console.Write("[");
            Console.ForegroundColor = corAleatoria;
            Console.Write("2");
            Console.ResetColor();
            Console.Write("] Info\n");
            /////////////
            Console.Write("[");
            Console.ForegroundColor = corAleatoria;
            Console.Write("3");
            Console.ResetColor();
            Console.Write("] Sair\n");
            /////////////
            Console.ForegroundColor = corAleatoria;
            Console.WriteLine("\n\n\n\n\n\n\n Escolha uma das Opções:");
            string opcao2 = Console.ReadLine();


            switch (opcao2)
            {
                case "1":
                    Console.ForegroundColor = corAleatoria;
                    Console.Clear();
                    Console.WriteLine(texto);
                    Console.ForegroundColor = ConsoleColor.White;

                    Console.WriteLine("\n1. Deletar Arquivos - FiveM                                         10. Acessar Canal Mottatiin");
                    Console.WriteLine("2. Abrir FiveM                                                      11. Acessar Fusion Systems");
                    Console.WriteLine("3. Fechar Steam");
                    Console.WriteLine("4. Fechar EpicGames");
                    Console.WriteLine("5. Trocar de conta - Varias Ações");
                    Console.WriteLine("6. Voltar");
                    Console.ForegroundColor = corAleatoria;
                    Console.WriteLine("\n\n\n\n\n\n\n Escolha uma das Opções:");
                    Console.ForegroundColor = ConsoleColor.White;
               
                    string opcao = Console.ReadLine();

                    switch (opcao)
                    {
                        case "1":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nDeletando...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;


                            DeletarArquivosDigitalEntitlements();
                            DeletarArquivosDigitalEntitlements2();
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                        case "2":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nAbrindo...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            string diretorioDoUsuario = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                            string caminhoDoFiveM = System.IO.Path.Combine(diretorioDoUsuario, "FiveM", "FiveM.exe");

                            try
                            {
                                Process.Start(caminhoDoFiveM);
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Ocorreu um erro ao abrir o FiveM: {ex.Message}");
                            }
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                        case "3":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nFechando...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            CloseSteam();
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;

                        case "4":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nFechando...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            CloseEpic();
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                        case "5":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nPreparando...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            CloseEpic();
                            Thread.Sleep(500);
                            CloseSteam();
                            Thread.Sleep(500);
                            DeletarArquivosDigitalEntitlements();
                            Thread.Sleep(500);
                            DeletarArquivosDigitalEntitlements2();
                            string diretorioDoUsuario2 = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
                            string caminhoDoFiveM2 = System.IO.Path.Combine(diretorioDoUsuario2, "FiveM", "FiveM.exe");
                            Thread.Sleep(500);
                            try
                            {
                                Process.Start(caminhoDoFiveM2);
                                Console.WriteLine("FiveM Iniciado!");
                            }
                            catch (Exception ex)
                            {
                                Console.WriteLine($"Ocorreu um erro ao abrir o FiveM: {ex.Message}");
                            }
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                        case "6":
                            Console.Clear();
                            break;
                        case "10":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nAcessando Canal...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(500);
                            string urlmottatiin = "https://www.youtube.com/channel/UC_VN-pYDxkdaVURfvxm-fMw";
                            Process.Start("cmd", $"/c start {urlmottatiin}");
                            Console.WriteLine("Canal Aberto!");
                            Thread.Sleep(1500);
                            Console.Clear();
                            break;
                        case "11":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nAcessando Discord...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(500);
                            Process.Start("cmd", $"/c start {url}");
                            Console.WriteLine("Canal Aberto!");
                            Thread.Sleep(1500);
                            Console.Clear();
                            break;
                        default:
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nOpção inválida. Por favor, selecione uma opção válida....\n");
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                    }

                    break;

                case "2":
                    Console.ForegroundColor = corAleatoria;
                    Console.Clear();
                    Console.WriteLine(texto);
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[");
                    Console.ForegroundColor = corAleatoria;
                    Console.Write("*");
                    Console.ResetColor();
                    Console.Write("] Este é um aplicativo para facilitar ações rápidas desenvolvido por @mottatiin, caso deseje\nentrar em contato você pode acessar nosso servidor de discord e abrir um ticket!\n");
                    /////////////
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[");
                    Console.ForegroundColor = corAleatoria;
                    Console.Write("*");
                    Console.ResetColor();
                    Console.Write("] O Discord abaixo se trata de um servidor referente a websites, aplicações e bots.\nCaso esteja interessado em algum projeto como bots para seu servidor e diversos, estaremos dispostos a ajudar!\n\n\n");
                    /////////////
                    Console.Write("[");
                    Console.ForegroundColor = corAleatoria;
                    Console.Write("1");
                    Console.ResetColor();
                    Console.Write("] Acessar Discord\n");
                    /////////////
                    Console.Write("[");
                    Console.ForegroundColor = corAleatoria;
                    Console.Write("2");
                    Console.ResetColor();
                    Console.Write("] Voltar\n");
                    /////////////
                    Console.ForegroundColor = corAleatoria;
                    Console.WriteLine("\n\n\n\n\n\n\n Escolha uma das Opções:");
                    Console.ForegroundColor = ConsoleColor.White;

                    string opcao3 = Console.ReadLine();

                    switch (opcao3)
                    {
                        case "1":
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nAcessando Discord...\n\n\n\nDebug:");
                            Console.ForegroundColor = ConsoleColor.White;
                            Thread.Sleep(500);
                            Process.Start("cmd", $"/c start {url}");
                            Console.WriteLine("Canal Aberto!");
                            Thread.Sleep(1500);
                            Console.Clear();
                            break;                   
                        case "2":
                            Console.Clear();
                            break;
                        default:
                            Console.Clear();
                            Console.ForegroundColor = corAleatoria;
                            Console.WriteLine("\n\nOpção inválida. Por favor, selecione uma opção válida....\n");
                            Thread.Sleep(2000);
                            Console.Clear();
                            break;
                    }

                    break;

                case "3":
                    Console.Clear();
                    Console.ForegroundColor = corAleatoria;
                    Console.WriteLine("\n\nFechando...\n");
                    Thread.Sleep(2000);
                    return;

                default:
                    Console.Clear();
                    Console.ForegroundColor = corAleatoria;
                    Console.WriteLine("\n\nOpção inválida. Por favor, selecione uma opção válida....\n");
                    Thread.Sleep(2000);
                    Console.Clear();
                    break;
        }


        }
    }

    static void DeletarArquivosDigitalEntitlements()
    {
        string diretorioAlvo = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DigitalEntitlements");
        string diretorioAlvo2 = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FiveM", "FiveM.app", "crashes");

        if (Directory.Exists(diretorioAlvo))
        {
            try
            {
                string[] arquivos = Directory.GetFiles(diretorioAlvo);
                string[] arquivos2 = Directory.GetFiles(diretorioAlvo2);

                foreach (string arquivo in arquivos)
                {
                    File.Delete(arquivo);
                    Console.WriteLine($"Arquivo excluído: {arquivo}");
                }
                foreach (string arquivo2 in arquivos2)
                {
                    File.Delete(arquivo2);
                    Console.WriteLine($"Arquivo excluído: {arquivo2}");
                }

                Console.WriteLine("Todos os arquivos foram excluídos com sucesso.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ocorreu um erro ao excluir os arquivos: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine("O diretório não existe.");
        }
    }

    static void CloseSteam()
    {
        // Nome do processo do Steam
        string steamProcessName = "steamwebhelper";

        // Procura todos os processos com o nome "Steam"
        Process[] processes = Process.GetProcessesByName(steamProcessName);

        if (processes.Length > 0)
        {
            foreach (Process process in processes)
            {
                // Encerra cada instância do Steam
                process.CloseMainWindow(); // Tenta fechar a janela principal do Steam
                process.WaitForExit(5000); // Aguarda até 5 segundos para a finalização

                // Se o processo ainda estiver em execução após a tentativa de fechamento suave,
                // encerra o processo forçadamente
                if (!process.HasExited)
                {
                    process.Kill();
                }
            }


        }

        // 
        // Nome do processo do Steam
        string steamProcessName2 = "steam";

        // Procura todos os processos com o nome "Steam"
        Process[] processes2 = Process.GetProcessesByName(steamProcessName2);

        if (processes.Length > 0)
        {
            foreach (Process process in processes2)
            {
                // Encerra cada instância do Steam
                process.CloseMainWindow(); // Tenta fechar a janela principal do Steam
                process.WaitForExit(5000); // Aguarda até 5 segundos para a finalização

                // Se o processo ainda estiver em execução após a tentativa de fechamento suave,
                // encerra o processo forçadamente
                if (!process.HasExited)
                {
                    process.Kill();
                }
            }

            Console.WriteLine("Steam fechado com sucesso.");
        }
        else
        {
            Console.WriteLine("Steam não está em execução.");
        }
    }

    static void CloseEpic()
    {
        // Nome do processo do Epic
        string EpicProcessName = "EpicGamesLauncher";

        // Procura todos os processos com o nome "Epic"
        Process[] processes = Process.GetProcessesByName(EpicProcessName);

        if (processes.Length > 0)
        {
            foreach (Process process in processes)
            {
                // Encerra cada instância do Epic
                process.CloseMainWindow(); // Tenta fechar a janela principal do Epic
                process.WaitForExit(5000); // Aguarda até 5 segundos para a finalização

                // Se o processo ainda estiver em execução após a tentativa de fechamento suave,
                // encerra o processo forçadamente
                if (!process.HasExited)
                {
                    process.Kill();
                }
            }

            Console.WriteLine("EpicGames fechada com sucesso.");
        }
        else
        {
            Console.WriteLine("EpicGames não está em execução.");
        }
    }

    static void EscreverLentamente(string texto)
    {
        foreach (char c in texto)
        {
            Console.Write(c);
            Thread.Sleep(01); // Ajuste este valor para controlar a velocidade da animação
        }
    }

    static void DeletarArquivosDigitalEntitlements2()
    {
        string diretorioFiveM = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "FiveM", "FiveM.app");

        string[] pastasParaExcluir = { "cache", "nui-storage", "server-cache", "server-cache-priv" };

        foreach (string pasta in pastasParaExcluir)
        {
            string pastaParaExcluir = Path.Combine(diretorioFiveM, "data", pasta);

            if (Directory.Exists(pastaParaExcluir))
            {
                try
                {
                    Directory.Delete(pastaParaExcluir, true);
                    Console.WriteLine($"Pasta excluída com sucesso: {pastaParaExcluir}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao excluir a pasta {pastaParaExcluir}: {ex.Message}");
                }
            }
            else
            {
                Console.WriteLine($"A pasta {pastaParaExcluir} não existe.");
            }
        }

        string pastaParaExcluir2 = Path.Combine(diretorioFiveM, "logs");
        if (Directory.Exists(pastaParaExcluir2))
        {
            try
            {
                Directory.Delete(pastaParaExcluir2, true);
                Console.WriteLine($"Pasta excluída com sucesso: {pastaParaExcluir2}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao excluir a pasta {pastaParaExcluir2}: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine($"A pasta {pastaParaExcluir2} não existe.");
        }


        string pastaParaExcluir3 = Path.Combine(diretorioFiveM, "crashes");
        if (Directory.Exists(pastaParaExcluir3))
        {
            try
            {
                Directory.Delete(pastaParaExcluir3, true);
                Console.WriteLine($"Pasta excluída com sucesso: {pastaParaExcluir2}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao excluir a pasta {pastaParaExcluir3}: {ex.Message}");
            }
        }
        else
        {
            Console.WriteLine($"A pasta {pastaParaExcluir3} não existe.");
        }

        Console.WriteLine("Todas as pastas foram excluídas com sucesso.");
    }
}



