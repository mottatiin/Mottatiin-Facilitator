﻿namespace System.Windows
{
    internal class Application
    {
    }
}